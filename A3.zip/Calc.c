#include <jni.h>
#include <stab.h>
#include "Calc.h"

JNIEXPORT double JNICALL Java_Calc_add(JNIEnv *env, jobject obj, jdouble a, jdouble b)
{
    double result = a + b;
    return result;
}

JNIEXPORT double JNICALL Java_Calc_sub(JNIEnv *env, jobject obj, jdouble a, jdouble b)
{
    double result = a - b;
    return result;
}

JNIEXPORT double JNICALL Java_Calc_mul(JNIEnv *env, jobject obj, jdouble a, jdouble b)
{
    double result = a * b;
    return result;
}

JNIEXPORT double JNICALL Java_Calc_div(JNIEnv *env, jobject obj, jdouble a, jdouble b)
{
    double result = a / b;
    return result;
}