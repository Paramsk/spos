import java.util.Scanner;

public class Calc {

    static {
        System.loadLibrary("calc");
    }

    private native double add(double a, double b);

    private native double sub(double a, double b);

    private native double mul(double a, double b);

    private native double div(double a, double b);

    private double result;

    public int menu() {
        Scanner sc = new Scanner(System.in);
        double a, b;
        int ch;

        System.out.println("\nEnter first value:");
        a = sc.nextDouble();
        System.out.println("\nEnter second value:");
        b = sc.nextDouble();

        System.out.println("\n1 For Addition");
        System.out.println("\n2 For Subtraction");
        System.out.println("\n3 For Multiplication");
        System.out.println("\n4 For Division");
        System.out.println("\nEnter Your Choice:");
        ch = sc.nextInt();
        sc.close();

        switch (ch) {
            case 1:
                result = add(a, b);
                break;

            case 2:
                result = sub(a, b);
                break;

            case 3:
                result = mul(a, b);
                break;

            case 4:
                result = div(a, b);
                break;

            default:
                System.out.println("Not A Valid Choice");
                return 1;
        }
        System.out.println("Result Is: " + result);
        return 0;
    }

    public static void main(String[] args) {
        Calc calc = new Calc();
        calc.menu();
    }
}
