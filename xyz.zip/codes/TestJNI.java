import java.io.*;
import java.util.*;

public class TestJNI {
    static {
        System.loadLibrary("cal");
    }
    public native int add(int a, int b);
    public static void main (String [] args) throws IOException {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter values of A and B : ");
        String num1    = input.nextLine();
        int a = Integer.parseInt(num1);
        String num2    = input.nextLine();
        int b = Integer.parseInt(num2);
        
        System.out.println("The Addition is ="+new TestJNI().add(a,b));
    }
}
  